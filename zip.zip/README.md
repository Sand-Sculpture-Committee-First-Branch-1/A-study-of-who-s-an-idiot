红盟云卡系统是【红盟云商】旗下的一款基于PHP+MySQL开发的虚拟商品在线售卖平台

## 特别注意！！！

如非必要，请务必下载发行版。发行版是已通过测试的正式版本。

发行版下载链接：[http://www.hmy3.com/hmyk.html](http://www.hmy3.com/hmyk.html)

官方演示站链接：[http://shop.hmy3.com/](http://shop.hmy3.com/)

本项目中master分支下的是开发版！！！注意开发版处于开发阶段！！！不能上线使用！！！

## 问题反馈

在使用中有任何问题，请使用以下联系方式联系我们

红盟云QQ交流群: 243438998

Gitee: https://gitee.com/daua/kamiduli

## 截图展示
![前台首页](image/img_5.png)

![后台首页](image/da.jpg)

![支付配置](image/img.png)

![商品管理](image/img_1.png)

![订单管理](image/img_2.png)

![对接管理](image/img_3.png)

![插件管理](image/img_4.png)


## 版权信息

红盟云卡系统遵循Apache2开源协议发布，并提供免费使用。

本项目包含的第三方源码和二进制文件之版权信息另行标注。

版权所有Copyright © 2017-2020 by 红盟云商 (https://www.hmyblog.com)

All rights reserved。
