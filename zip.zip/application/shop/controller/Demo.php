<?php

namespace app\index\controller;


class Demo extends Base {


    public function index() {
        return view();
    }

}
