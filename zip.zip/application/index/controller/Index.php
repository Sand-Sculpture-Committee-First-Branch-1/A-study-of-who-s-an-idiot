<?php

namespace app\index\controller;

use fast\Http;
use think\Controller;

class Index extends Controller {

    public function upgrade(){

        /*Http::get();

        //判断版本表是否存在
        $isTable= db::query('SHOW TABLES LIKE "%_version"');
        if($isTable){
            //表存在
        }else{
            //表不存在
        }*/


    }

}
