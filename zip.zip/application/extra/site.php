<?php

return [
    'shop_title' => '红盟云卡在线自动发卡系统 - 全国最大的虚拟货源销售平台',
    'shop_pet_name' => '红盟云卡',
    'beian' => '',
    'version' => '1617802074',
    'fixedpage' => 'dashboard',
    'configgroup' => [
        'basic' => 'Basic',
        'money' => '资金配置',
        'other' => '其他配置',
    ],
    'min_cashout' => '0',
    'max_cashout_num' => '3',
    'cashout_charged' => '1',
    'tourist_buy' => '1',
    'login' => '1',
    'register' => '1',
    'statistics' => '',
    'diy_name' => '商品购买',
    'search_password' => '1',
];
