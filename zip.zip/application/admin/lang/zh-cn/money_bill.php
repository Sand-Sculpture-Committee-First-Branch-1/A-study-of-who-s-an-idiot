<?php

return [
    'Type' => '类型'
];
