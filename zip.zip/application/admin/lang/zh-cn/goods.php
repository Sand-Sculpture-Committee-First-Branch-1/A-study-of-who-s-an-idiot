<?php

return [
    'Remote_id'  => '远程商品id',
    'Goods_type' => '0 卡密 1 激活码 2账号和密码',
    'Type'       => '产品类型',
    'Deliver'    => '发货方式0自动发货 1手动发货',
    'Stock'      => '库存',
    'Kami'       => '卡密'
];
