<?php

return [
    'Id'         => 'ID',
    'Name'       => '名称',
    'Value_json' => '内容',
    'Createtime' => '添加时间',
    'Updatetime' => '修改时间'
];
