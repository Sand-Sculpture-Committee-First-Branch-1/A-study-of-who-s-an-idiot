<?php

return [
    'Id'        => 'ID',
    'Directory' => '模板目录',
    'Name'      => '模板名称',
    'Author'    => '作者',
    'Version'   => '版本',
    'Status'    => '0正常 1关闭',
    'Cover'     => '封面图',
    'Default'   => '默认模板'
];
