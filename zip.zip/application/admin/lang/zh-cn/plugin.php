<?php

return [
    'Id'          => 'ID',
    'Title'       => '名称',
    'Description' => '描述',
    'Version'     => '版本',
    'Status'      => '状态'
];
