<?php

return [
    'Id'          => 'ID',
    'Uid'         => '用户id',
    'Goods_id'    => '商品id',
    'Goods_name'  => '商品名称',
    'Goods_cover' => '商品封面图',
    'Goods_num'   => '购买数量',
    'Goods_money' => '商品单价',
    'Money'       => '订单金额',
    'Pay'         => '支付状态 -1未支付 0余额 1支付宝',
    'Goods_type'  => '0 卡密 1 激活码 2账号和密码',
    'Status'      => '订单状态 0代发货 1待收货 9已完成',
    'Createtime'  => '创建时间',
    'Paytime'     => '支付时间'
];
