<?php

namespace app\admin\controller\docking;

use think\Cache;
use think\Db;
use think\Exception;
use think\exception\PDOException;
use think\exception\ValidateException;

/**
 * 对接站点公用
 *
 * @icon fa fa-circle-o
 */
class Dock{




}
