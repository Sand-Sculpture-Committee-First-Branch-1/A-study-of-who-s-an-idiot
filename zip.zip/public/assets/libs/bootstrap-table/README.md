# fastamin-bootstraptable
FastAdmin Bootstrap-table表格组件

## 使用方法
https://f4nniu.gitee.io/bootstrap-table-home/zh-cn/home/

## 特别感谢
https://github.com/wenzhixin/bootstrap-table